# Dustin Bot V1 (Android)

โปรเจกต์ตัวอย่างสำหรับ Android Accessibility Service

V1:
- ปุ่มลอย BOT / STOP
- แตะตามพิกัดที่ตั้งไว้
- ตั้งช่วงเวลาการแตะ
- มีพิกัดยา HP สำหรับต่อยอดในรุ่นถัดไป

ข้อจำกัด:
- รุ่นนี้ยังไม่ได้อ่าน HP จากภาพ
- ยังไม่ได้ตรวจจับมอนสเตอร์
- ยังไม่ได้เดินอัตโนมัติ
- ต้องเปิด Accessibility ให้แอป
- ใช้เฉพาะกับเกม/เซิร์ฟเวอร์ที่อนุญาตการทำ automation

วิธีเปิด:
1. เปิดโปรเจกต์ใน Android Studio
2. Build APK
3. ติดตั้ง APK
4. Settings > Accessibility > Dustin Bot V1 > เปิดใช้งาน
5. เปิด Dustin-RO และใช้ปุ่มลอย BOT

หมายเหตุ: พิกัดตัวอย่าง 1290,760 เป็นเพียงค่าจากภาพตัวอย่างและอาจไม่ตรงกับอุปกรณ์จริง ต้องปรับก่อนใช้


## Build APK โดยไม่ใช้คอม
โปรเจกต์นี้มี GitHub Actions ใน `.github/workflows/build-apk.yml`
เมื่ออัปโหลดเข้า GitHub แล้วสามารถกด Run workflow จากมือถือเพื่อ Build APK และดาวน์โหลด artifact ได้
