package com.dustinbot.v1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    EditText attackX, attackY, attackMs, hpX, hpY, hpPercent;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(30,30,30,30);

        TextView title = new TextView(this);
        title.setText("Dustin Bot V1\nบอทแตะหน้าจอสำหรับทดสอบ");
        title.setTextSize(20);
        l.addView(title);

        l.addView(label("จุดโจมตี X,Y"));
        attackX = edit("1290"); attackY = edit("760");
        l.addView(attackX); l.addView(attackY);

        l.addView(label("โจมตีทุกกี่ ms"));
        attackMs = edit("1200"); l.addView(attackMs);

        l.addView(label("จุดยา HP X,Y"));
        hpX = edit("1100"); hpY = edit("650");
        l.addView(hpX); l.addView(hpY);

        l.addView(label("HP ต่ำกว่า (%)"));
        hpPercent = edit("30"); l.addView(hpPercent);

        Button save = new Button(this); save.setText("บันทึกค่า");
        save.setOnClickListener(v -> saveSettings());
        l.addView(save);

        Button access = new Button(this); access.setText("เปิด Accessibility");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        l.addView(access);

        TextView note = new TextView(this);
        note.setText("\nวิธีใช้: เปิด Accessibility ของ Dustin Bot → กลับเกม → ใช้ปุ่มลอยของบอท\n\nV1 นี้เป็นตัวควบคุมการแตะตามพิกัดที่ตั้งไว้ ยังไม่มีระบบอ่าน HP จากภาพ/ค้นหามอนอัตโนมัติ");
        l.addView(note);

        setContentView(l);
    }

    TextView label(String s){ TextView t=new TextView(this); t.setText(s); t.setTextSize(16); return t; }
    EditText edit(String s){ EditText e=new EditText(this); e.setText(s); e.setInputType(2); return e; }

    void saveSettings(){
        getSharedPreferences("bot",0).edit()
            .putInt("ax", Integer.parseInt(attackX.getText().toString()))
            .putInt("ay", Integer.parseInt(attackY.getText().toString()))
            .putLong("ams", Long.parseLong(attackMs.getText().toString()))
            .putInt("hx", Integer.parseInt(hpX.getText().toString()))
            .putInt("hy", Integer.parseInt(hpY.getText().toString()))
            .putInt("hp", Integer.parseInt(hpPercent.getText().toString()))
            .apply();
        Toast.makeText(this,"บันทึกแล้ว",Toast.LENGTH_SHORT).show();
    }
}
