package com.dustinbot.v1;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class BotAccessibilityService extends AccessibilityService {
    WindowManager wm;
    LinearLayout panel;
    Handler handler = new Handler(Looper.getMainLooper());
    AtomicBoolean running = new AtomicBoolean(false);
    Runnable attackLoop;
    SharedPreferences sp;

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        sp = getSharedPreferences("bot",0);
        showPanel();
    }

    void showPanel() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(8,8,8,8);
        panel.setBackgroundColor(0xDD222222);

        Button start = new Button(this); start.setText("▶ BOT");
        Button stop = new Button(this); stop.setText("■ STOP");
        Button test = new Button(this); test.setText("แตะทดสอบ");
        TextView status = new TextView(this); status.setTextColor(0xFFFFFFFF); status.setText("พร้อม");

        panel.addView(start); panel.addView(stop); panel.addView(test); panel.addView(status);

        int type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
        wm.addView(panel,p);

        start.setOnClickListener(v -> {
            if (running.compareAndSet(false,true)) {
                status.setText("กำลังทำงาน");
                beginAttackLoop();
            }
        });
        stop.setOnClickListener(v -> {
            running.set(false); status.setText("หยุดแล้ว");
        });
        test.setOnClickListener(v -> tap(
            sp.getInt("ax",1290), sp.getInt("ay",760)));
    }

    void beginAttackLoop() {
        attackLoop = new Runnable() {
            @Override public void run() {
                if (!running.get()) return;
                tap(sp.getInt("ax",1290), sp.getInt("ay",760));
                handler.postDelayed(this, sp.getLong("ams",1200));
            }
        };
        handler.post(attackLoop);
    }

    void tap(int x, int y) {
        Path path = new Path();
        path.moveTo(x,y);
        GestureDescription.StrokeDescription stroke =
            new GestureDescription.StrokeDescription(path,0,50);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    @Override public void onDestroy() {
        running.set(false);
        if (wm != null && panel != null) wm.removeView(panel);
        super.onDestroy();
    }

    @Override public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent e) {}
    @Override public void onInterrupt() { running.set(false); }
}
